function(n,t,e){var o;function i(){return{type:o.CLOSE_CHAT_VIEW,show:!1}}function r(){return{type:o.OPEN_CHAT_VIEW,show:!0}}e.export({closeChatView:function(){return i},openChatView:function(){return r}}),e.watch(n("./types"),{"*":function(n){o=n}},0)}

