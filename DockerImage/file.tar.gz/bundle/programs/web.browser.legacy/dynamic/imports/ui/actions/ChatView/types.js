function(_,n,E){E.export({OPEN_CHAT_VIEW:function(){return r},CLOSE_CHAT_VIEW:function(){return t}});var r="OPEN_CHAT_VIEW",t="CLOSE_CHAT_VIEW"}

