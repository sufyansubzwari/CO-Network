function(n,E,_){_.export({CHANGE_MOBILE_VIEW:function(){return i}});var i="CHANGE_MOBILE_VIEW"}

