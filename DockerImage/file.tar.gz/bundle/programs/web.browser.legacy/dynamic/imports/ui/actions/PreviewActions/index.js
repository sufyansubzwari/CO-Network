function(t,n,e){var i;function r(t,n,e){return{showPreview:!!t,entity:t,entityType:e,type:t?i.SHOW_PREVIEW:i.HIDE_PREVIEW}}e.export({PreviewData:function(){return r}}),e.watch(t("./types"),{"*":function(t){i=t}},0)}

