function(t,n,i){var e;function u(t){return{type:e.CHANGE_MOBILE_VIEW,status:t}}i.export({isMobileView:function(){return u}}),i.watch(t("./types"),{"*":function(t){e=t}},0)}

