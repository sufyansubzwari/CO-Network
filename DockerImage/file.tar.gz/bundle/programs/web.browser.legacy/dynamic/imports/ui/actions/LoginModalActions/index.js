function(n,t,o){var i;function r(){return{type:i.LOGIN_MODAL_SHOW,show:!0}}function u(){return{type:i.LOGIN_MODAL_HIDEN,show:!1}}o.export({loginModalShow:function(){return r},loginModalHide:function(){return u}}),o.watch(n("./types"),{"*":function(n){i=n}},0)}

