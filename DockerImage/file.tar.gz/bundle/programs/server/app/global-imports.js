/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
ECMAScript = Package.ecmascript.ECMAScript;
ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
check = Package.check.check;
Match = Package.check.Match;
Collection2 = Package['aldeed:collection2-core'].Collection2;
Roles = Package['alanning:roles'].Roles;
chai = Package['practicalmeteor:chai'].chai;
assert = Package['practicalmeteor:chai'].assert;
expect = Package['practicalmeteor:chai'].expect;
should = Package['practicalmeteor:chai'].should;
ReactMeteorData = Package['react-meteor-data'].ReactMeteorData;
enableDebugLogging = Package['reywood:publish-composite'].enableDebugLogging;
publishComposite = Package['reywood:publish-composite'].publishComposite;
Slingshot = Package['edgee:slingshot'].Slingshot;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
WebAppInternals = Package.webapp.WebAppInternals;
main = Package.webapp.main;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
meteorInstall = Package.modules.meteorInstall;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
Accounts = Package['accounts-base'].Accounts;
Facebook = Package['facebook-oauth'].Facebook;
BrowserPolicy = Package['browser-policy-common'].BrowserPolicy;
Autoupdate = Package.autoupdate.Autoupdate;

