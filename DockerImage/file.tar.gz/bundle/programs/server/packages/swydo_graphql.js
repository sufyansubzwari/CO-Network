(function () {



/* Exports */
Package._define("swydo:graphql");

})();
