(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Collection2 = Package['aldeed:collection2-core'].Collection2;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

var require = meteorInstall({"node_modules":{"meteor":{"orcprogramming:collection2-core-server":{"collection2-core-server.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orcprogramming_collection2-core-server/collection2-core- //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.watch(require("meteor/aldeed:collection2-core"), {
  default(v) {
    exports.Collection2 = v;
  }

}, 0);
///////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/orcprogramming:collection2-core-server/collection2-core-server.js");

/* Exports */
Package._define("orcprogramming:collection2-core-server", exports, {
  Collection2: Collection2
});

})();

//# sourceURL=meteor://💻app/packages/orcprogramming_collection2-core-server.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3JjcHJvZ3JhbW1pbmc6Y29sbGVjdGlvbjItY29yZS1zZXJ2ZXIvY29sbGVjdGlvbjItY29yZS1zZXJ2ZXIuanMiXSwibmFtZXMiOlsibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwiZGVmYXVsdCIsInYiLCJleHBvcnRzIiwiQ29sbGVjdGlvbjIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWIsRUFBdUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLFlBQVFDLFdBQVIsR0FBb0JGLENBQXBCO0FBQXNCOztBQUFsQyxDQUF2RCxFQUEyRixDQUEzRixFIiwiZmlsZSI6Ii9wYWNrYWdlcy9vcmNwcm9ncmFtbWluZ19jb2xsZWN0aW9uMi1jb3JlLXNlcnZlci5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIERvIG5vdGhpbmcgd2l0aCBDb2xsZWN0aW9uMiBuYW1lc3BhY2UsIGp1c3QgcGFzcyBpdCBkb3duIGFzIHByb3ZpZGVkIGJ5XG4vLyBhbGRlZWQ6Y29sbGVjdGlvbjItY29yZVxuZXhwb3J0IHsgZGVmYXVsdCBhcyBDb2xsZWN0aW9uMiB9IGZyb20gJ21ldGVvci9hbGRlZWQ6Y29sbGVjdGlvbjItY29yZSc7XG4iXX0=
