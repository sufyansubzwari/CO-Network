(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Accounts = Package['accounts-base'].Accounts;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"apollo":{"src":{"main-server.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/apollo/src/main-server.js                                                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
var _interopRequireDefault = require("@babel/runtime/helpers/builtin/interopRequireDefault");

var _objectSpread2 = _interopRequireDefault(require("@babel/runtime/helpers/builtin/objectSpread"));

module.export({
  createApolloServer: () => createApolloServer,
  getUserForContext: () => getUserForContext,
  addCurrentUserToContext: () => addCurrentUserToContext
});
let graphqlExpress, graphiqlExpress;
module.watch(require("apollo-server-express"), {
  graphqlExpress(v) {
    graphqlExpress = v;
  },

  graphiqlExpress(v) {
    graphiqlExpress = v;
  }

}, 0);
let bodyParser;
module.watch(require("body-parser"), {
  default(v) {
    bodyParser = v;
  }

}, 1);
let express;
module.watch(require("express"), {
  default(v) {
    express = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let WebApp;
module.watch(require("meteor/webapp"), {
  WebApp(v) {
    WebApp = v;
  }

}, 4);
let Accounts;
module.watch(require("meteor/accounts-base"), {
  Accounts(v) {
    Accounts = v;
  }

}, 5);
let check;
module.watch(require("meteor/check"), {
  check(v) {
    check = v;
  }

}, 6);
// default server configuration object
const defaultServerConfig = {
  // graphql endpoint
  path: '/graphql',
  // additional Express server configuration (enable CORS there for instance)
  configServer: graphQLServer => {},
  // enable GraphiQL only in development mode
  graphiql: Meteor.isDevelopment,
  // GraphiQL endpoint
  graphiqlPath: '/graphiql',
  // GraphiQL options (default: log the current user in your request)
  graphiqlOptions: {
    passHeader: "'meteor-login-token': localStorage['Meteor.loginToken']"
  }
}; // default graphql options to enhance the graphQLExpress server

const defaultGraphQLOptions = {
  // ensure that a context object is defined for the resolvers
  context: {},
  // error formatting
  formatError: e => ({
    message: e.message,
    locations: e.locations,
    path: e.path
  }),
  // additional debug logging if execution errors occur in dev mode
  debug: Meteor.isDevelopment
};

const createApolloServer = (customOptions = {}, customConfig = {}) => {
  // create a new server config object based on the default server config
  // defined above and the custom server config passed to this function
  const config = (0, _objectSpread2.default)({}, defaultServerConfig, customConfig);

  if (customConfig.graphiqlOptions) {
    config.graphiqlOptions = (0, _objectSpread2.default)({}, defaultServerConfig.graphiqlOptions, customConfig.graphiqlOptions);
  } // the Meteor GraphQL server is an Express server


  const graphQLServer = express(); // enhance the GraphQL server with possible express middlewares

  config.configServer(graphQLServer); // GraphQL endpoint, enhanced with JSON body parser

  graphQLServer.use(config.path, bodyParser.json(), graphqlExpress(req => Promise.asyncApply(() => {
    try {
      // graphqlExpress can accept a function returning the option object
      const customOptionsObject = typeof customOptions === 'function' ? customOptions(req) : customOptions; // create a new apollo options object based on the default apollo options
      // defined above and the custom apollo options passed to this function

      const options = (0, _objectSpread2.default)({}, defaultGraphQLOptions, customOptionsObject); // get the login token from the headers request, given by the Meteor's
      // network interface middleware if enabled

      const loginToken = req.headers['meteor-login-token']; // get the current user & the user id for the context

      const userContext = Promise.await(getUserForContext(loginToken)); // context can accept a function returning the context object

      const context = typeof options.context === 'function' ? Promise.await(options.context(userContext)) : (0, _objectSpread2.default)({}, options.context, userContext); // return the configured options to be used by the graphql server

      return (0, _objectSpread2.default)({}, options, {
        context
      });
    } catch (error) {
      // something went bad when configuring the graphql server, we do not
      // swallow the error and display it in the server-side logs
      console.error('[Meteor Apollo Integration] Something bad happened when handling a request on the GraphQL server. Your GraphQL server is not working as expected:', error); // return the default graphql options anyway

      return defaultGraphQLOptions;
    }
  }))); // Start GraphiQL if enabled

  if (config.graphiql) {
    // GraphiQL endpoint
    graphQLServer.use(config.graphiqlPath, graphiqlExpress((0, _objectSpread2.default)({}, config.graphiqlOptions, {
      // endpoint of the graphql server where to send requests
      endpointURL: config.path
    })));
  } // this binds the specified paths to the Express server running Apollo + GraphiQL


  WebApp.connectHandlers.use(graphQLServer);
};

const getUserForContext = loginToken => Promise.asyncApply(() => {
  // there is a possible current user connected!
  if (loginToken) {
    // throw an error if the token is not a string
    check(loginToken, String); // the hashed token is the key to find the possible current user in the db

    const hashedToken = Accounts._hashLoginToken(loginToken); // get the possible current user from the database
    // note: no need of a fiber aware findOne + a fiber aware call break tests
    // runned with practicalmeteor:mocha if eslint is enabled


    const currentUser = Promise.await(Meteor.users.rawCollection().findOne({
      'services.resume.loginTokens.hashedToken': hashedToken
    })); // the current user exists

    if (currentUser) {
      // find the right login token corresponding, the current user may have
      // several sessions logged on different browsers / computers
      const tokenInformation = currentUser.services.resume.loginTokens.find(tokenInfo => tokenInfo.hashedToken === hashedToken); // get an exploitable token expiration date

      const expiresAt = Accounts._tokenExpiration(tokenInformation.when); // true if the token is expired


      const isExpired = expiresAt < new Date(); // if the token is still valid, give access to the current user
      // information in the resolvers context

      if (!isExpired) {
        // return a new context object with the current user & her id
        return {
          user: currentUser,
          userId: currentUser._id
        };
      }
    }
  }

  return {};
});

const addCurrentUserToContext = (context, loginToken) => Promise.asyncApply(() => {
  const userContext = Promise.await(getUserForContext(loginToken));
  return (0, _objectSpread2.default)({}, context, userContext);
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/apollo/src/main-server.js");

/* Exports */
Package._define("apollo", exports);

})();

//# sourceURL=meteor://💻app/packages/apollo.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYXBvbGxvL3NyYy9tYWluLXNlcnZlci5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJjcmVhdGVBcG9sbG9TZXJ2ZXIiLCJnZXRVc2VyRm9yQ29udGV4dCIsImFkZEN1cnJlbnRVc2VyVG9Db250ZXh0IiwiZ3JhcGhxbEV4cHJlc3MiLCJncmFwaGlxbEV4cHJlc3MiLCJ3YXRjaCIsInJlcXVpcmUiLCJ2IiwiYm9keVBhcnNlciIsImRlZmF1bHQiLCJleHByZXNzIiwiTWV0ZW9yIiwiV2ViQXBwIiwiQWNjb3VudHMiLCJjaGVjayIsImRlZmF1bHRTZXJ2ZXJDb25maWciLCJwYXRoIiwiY29uZmlnU2VydmVyIiwiZ3JhcGhRTFNlcnZlciIsImdyYXBoaXFsIiwiaXNEZXZlbG9wbWVudCIsImdyYXBoaXFsUGF0aCIsImdyYXBoaXFsT3B0aW9ucyIsInBhc3NIZWFkZXIiLCJkZWZhdWx0R3JhcGhRTE9wdGlvbnMiLCJjb250ZXh0IiwiZm9ybWF0RXJyb3IiLCJlIiwibWVzc2FnZSIsImxvY2F0aW9ucyIsImRlYnVnIiwiY3VzdG9tT3B0aW9ucyIsImN1c3RvbUNvbmZpZyIsImNvbmZpZyIsInVzZSIsImpzb24iLCJyZXEiLCJjdXN0b21PcHRpb25zT2JqZWN0Iiwib3B0aW9ucyIsImxvZ2luVG9rZW4iLCJoZWFkZXJzIiwidXNlckNvbnRleHQiLCJlcnJvciIsImNvbnNvbGUiLCJlbmRwb2ludFVSTCIsImNvbm5lY3RIYW5kbGVycyIsIlN0cmluZyIsImhhc2hlZFRva2VuIiwiX2hhc2hMb2dpblRva2VuIiwiY3VycmVudFVzZXIiLCJ1c2VycyIsInJhd0NvbGxlY3Rpb24iLCJmaW5kT25lIiwidG9rZW5JbmZvcm1hdGlvbiIsInNlcnZpY2VzIiwicmVzdW1lIiwibG9naW5Ub2tlbnMiLCJmaW5kIiwidG9rZW5JbmZvIiwiZXhwaXJlc0F0IiwiX3Rva2VuRXhwaXJhdGlvbiIsIndoZW4iLCJpc0V4cGlyZWQiLCJEYXRlIiwidXNlciIsInVzZXJJZCIsIl9pZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE9BQU9DLE1BQVAsQ0FBYztBQUFDQyxzQkFBbUIsTUFBSUEsa0JBQXhCO0FBQTJDQyxxQkFBa0IsTUFBSUEsaUJBQWpFO0FBQW1GQywyQkFBd0IsTUFBSUE7QUFBL0csQ0FBZDtBQUF1SixJQUFJQyxjQUFKLEVBQW1CQyxlQUFuQjtBQUFtQ04sT0FBT08sS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0gsaUJBQWVJLENBQWYsRUFBaUI7QUFBQ0oscUJBQWVJLENBQWY7QUFBaUIsR0FBcEM7O0FBQXFDSCxrQkFBZ0JHLENBQWhCLEVBQWtCO0FBQUNILHNCQUFnQkcsQ0FBaEI7QUFBa0I7O0FBQTFFLENBQTlDLEVBQTBILENBQTFIO0FBQTZILElBQUlDLFVBQUo7QUFBZVYsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDRyxVQUFRRixDQUFSLEVBQVU7QUFBQ0MsaUJBQVdELENBQVg7QUFBYTs7QUFBekIsQ0FBcEMsRUFBK0QsQ0FBL0Q7QUFBa0UsSUFBSUcsT0FBSjtBQUFZWixPQUFPTyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNHLFVBQVFGLENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQWhDLEVBQXdELENBQXhEO0FBQTJELElBQUlJLE1BQUo7QUFBV2IsT0FBT08sS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDSyxTQUFPSixDQUFQLEVBQVM7QUFBQ0ksYUFBT0osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJSyxNQUFKO0FBQVdkLE9BQU9PLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ00sU0FBT0wsQ0FBUCxFQUFTO0FBQUNLLGFBQU9MLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSU0sUUFBSjtBQUFhZixPQUFPTyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFQUE2QztBQUFDTyxXQUFTTixDQUFULEVBQVc7QUFBQ00sZUFBU04sQ0FBVDtBQUFXOztBQUF4QixDQUE3QyxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJTyxLQUFKO0FBQVVoQixPQUFPTyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNRLFFBQU1QLENBQU4sRUFBUTtBQUFDTyxZQUFNUCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBU3BzQjtBQUNBLE1BQU1RLHNCQUFzQjtBQUMxQjtBQUNBQyxRQUFNLFVBRm9CO0FBRzFCO0FBQ0FDLGdCQUFjQyxpQkFBaUIsQ0FBRSxDQUpQO0FBSzFCO0FBQ0FDLFlBQVVSLE9BQU9TLGFBTlM7QUFPMUI7QUFDQUMsZ0JBQWMsV0FSWTtBQVMxQjtBQUNBQyxtQkFBaUI7QUFDZkMsZ0JBQVk7QUFERztBQVZTLENBQTVCLEMsQ0FlQTs7QUFDQSxNQUFNQyx3QkFBd0I7QUFDNUI7QUFDQUMsV0FBUyxFQUZtQjtBQUc1QjtBQUNBQyxlQUFhQyxNQUFNO0FBQ2pCQyxhQUFTRCxFQUFFQyxPQURNO0FBRWpCQyxlQUFXRixFQUFFRSxTQUZJO0FBR2pCYixVQUFNVyxFQUFFWDtBQUhTLEdBQU4sQ0FKZTtBQVM1QjtBQUNBYyxTQUFPbkIsT0FBT1M7QUFWYyxDQUE5Qjs7QUFhTyxNQUFNcEIscUJBQXFCLENBQUMrQixnQkFBZ0IsRUFBakIsRUFBcUJDLGVBQWUsRUFBcEMsS0FBMkM7QUFDM0U7QUFDQTtBQUNBLFFBQU1DLHlDQUNEbEIsbUJBREMsRUFFRGlCLFlBRkMsQ0FBTjs7QUFLQSxNQUFJQSxhQUFhVixlQUFqQixFQUFrQztBQUNoQ1csV0FBT1gsZUFBUCxtQ0FDS1Asb0JBQW9CTyxlQUR6QixFQUVLVSxhQUFhVixlQUZsQjtBQUlELEdBYjBFLENBZTNFOzs7QUFDQSxRQUFNSixnQkFBZ0JSLFNBQXRCLENBaEIyRSxDQWtCM0U7O0FBQ0F1QixTQUFPaEIsWUFBUCxDQUFvQkMsYUFBcEIsRUFuQjJFLENBcUIzRTs7QUFDQUEsZ0JBQWNnQixHQUFkLENBQ0VELE9BQU9qQixJQURULEVBRUVSLFdBQVcyQixJQUFYLEVBRkYsRUFHRWhDLGVBQXFCaUMsR0FBTiw2QkFBYTtBQUMxQixRQUFJO0FBQ0Y7QUFDQSxZQUFNQyxzQkFDSixPQUFPTixhQUFQLEtBQXlCLFVBQXpCLEdBQXNDQSxjQUFjSyxHQUFkLENBQXRDLEdBQTJETCxhQUQ3RCxDQUZFLENBS0Y7QUFDQTs7QUFDQSxZQUFNTywwQ0FDRGQscUJBREMsRUFFRGEsbUJBRkMsQ0FBTixDQVBFLENBWUY7QUFDQTs7QUFDQSxZQUFNRSxhQUFhSCxJQUFJSSxPQUFKLENBQVksb0JBQVosQ0FBbkIsQ0FkRSxDQWdCRjs7QUFDQSxZQUFNQyw0QkFBb0J4QyxrQkFBa0JzQyxVQUFsQixDQUFwQixDQUFOLENBakJFLENBbUJGOztBQUNBLFlBQU1kLFVBQ0osT0FBT2EsUUFBUWIsT0FBZixLQUEyQixVQUEzQixpQkFDVWEsUUFBUWIsT0FBUixDQUFnQmdCLFdBQWhCLENBRFYsb0NBRVNILFFBQVFiLE9BRmpCLEVBRTZCZ0IsV0FGN0IsQ0FERixDQXBCRSxDQXlCRjs7QUFDQSw2Q0FDS0gsT0FETDtBQUVFYjtBQUZGO0FBSUQsS0E5QkQsQ0E4QkUsT0FBT2lCLEtBQVAsRUFBYztBQUNkO0FBQ0E7QUFDQUMsY0FBUUQsS0FBUixDQUNFLG1KQURGLEVBRUVBLEtBRkYsRUFIYyxDQVFkOztBQUNBLGFBQU9sQixxQkFBUDtBQUNEO0FBQ0YsR0ExQ2MsQ0FBZixDQUhGLEVBdEIyRSxDQXNFM0U7O0FBQ0EsTUFBSVMsT0FBT2QsUUFBWCxFQUFxQjtBQUNuQjtBQUNBRCxrQkFBY2dCLEdBQWQsQ0FDRUQsT0FBT1osWUFEVCxFQUVFakIsZ0RBRUs2QixPQUFPWCxlQUZaO0FBR0U7QUFDQXNCLG1CQUFhWCxPQUFPakI7QUFKdEIsT0FGRjtBQVNELEdBbEYwRSxDQW1GM0U7OztBQUNBSixTQUFPaUMsZUFBUCxDQUF1QlgsR0FBdkIsQ0FBMkJoQixhQUEzQjtBQUNELENBckZNOztBQXVGQSxNQUFNakIsb0JBQTBCc0MsVUFBTiw2QkFBb0I7QUFDbkQ7QUFDQSxNQUFJQSxVQUFKLEVBQWdCO0FBQ2Q7QUFDQXpCLFVBQU15QixVQUFOLEVBQWtCTyxNQUFsQixFQUZjLENBSWQ7O0FBQ0EsVUFBTUMsY0FBY2xDLFNBQVNtQyxlQUFULENBQXlCVCxVQUF6QixDQUFwQixDQUxjLENBT2Q7QUFDQTtBQUNBOzs7QUFDQSxVQUFNVSw0QkFBb0J0QyxPQUFPdUMsS0FBUCxDQUFhQyxhQUFiLEdBQTZCQyxPQUE3QixDQUFxQztBQUM3RCxpREFBMkNMO0FBRGtCLEtBQXJDLENBQXBCLENBQU4sQ0FWYyxDQWNkOztBQUNBLFFBQUlFLFdBQUosRUFBaUI7QUFDZjtBQUNBO0FBQ0EsWUFBTUksbUJBQW1CSixZQUFZSyxRQUFaLENBQXFCQyxNQUFyQixDQUE0QkMsV0FBNUIsQ0FBd0NDLElBQXhDLENBQ3ZCQyxhQUFhQSxVQUFVWCxXQUFWLEtBQTBCQSxXQURoQixDQUF6QixDQUhlLENBT2Y7O0FBQ0EsWUFBTVksWUFBWTlDLFNBQVMrQyxnQkFBVCxDQUEwQlAsaUJBQWlCUSxJQUEzQyxDQUFsQixDQVJlLENBVWY7OztBQUNBLFlBQU1DLFlBQVlILFlBQVksSUFBSUksSUFBSixFQUE5QixDQVhlLENBYWY7QUFDQTs7QUFDQSxVQUFJLENBQUNELFNBQUwsRUFBZ0I7QUFDZDtBQUNBLGVBQU87QUFDTEUsZ0JBQU1mLFdBREQ7QUFFTGdCLGtCQUFRaEIsWUFBWWlCO0FBRmYsU0FBUDtBQUlEO0FBQ0Y7QUFDRjs7QUFFRCxTQUFPLEVBQVA7QUFDRCxDQTNDZ0MsQ0FBMUI7O0FBK0NBLE1BQU1oRSwwQkFBMEIsQ0FBT3VCLE9BQVAsRUFBZ0JjLFVBQWhCLDhCQUErQjtBQUNwRSxRQUFNRSw0QkFBb0J4QyxrQkFBa0JzQyxVQUFsQixDQUFwQixDQUFOO0FBQ0EseUNBQ0tkLE9BREwsRUFFS2dCLFdBRkw7QUFJRCxDQU5zQyxDQUFoQyxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9hcG9sbG8uanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBncmFwaHFsRXhwcmVzcywgZ3JhcGhpcWxFeHByZXNzIH0gZnJvbSAnYXBvbGxvLXNlcnZlci1leHByZXNzJztcbmltcG9ydCBib2R5UGFyc2VyIGZyb20gJ2JvZHktcGFyc2VyJztcbmltcG9ydCBleHByZXNzIGZyb20gJ2V4cHJlc3MnO1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFdlYkFwcCB9IGZyb20gJ21ldGVvci93ZWJhcHAnO1xuaW1wb3J0IHsgQWNjb3VudHMgfSBmcm9tICdtZXRlb3IvYWNjb3VudHMtYmFzZSc7XG5pbXBvcnQgeyBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjayc7XG5cbi8vIGRlZmF1bHQgc2VydmVyIGNvbmZpZ3VyYXRpb24gb2JqZWN0XG5jb25zdCBkZWZhdWx0U2VydmVyQ29uZmlnID0ge1xuICAvLyBncmFwaHFsIGVuZHBvaW50XG4gIHBhdGg6ICcvZ3JhcGhxbCcsXG4gIC8vIGFkZGl0aW9uYWwgRXhwcmVzcyBzZXJ2ZXIgY29uZmlndXJhdGlvbiAoZW5hYmxlIENPUlMgdGhlcmUgZm9yIGluc3RhbmNlKVxuICBjb25maWdTZXJ2ZXI6IGdyYXBoUUxTZXJ2ZXIgPT4ge30sXG4gIC8vIGVuYWJsZSBHcmFwaGlRTCBvbmx5IGluIGRldmVsb3BtZW50IG1vZGVcbiAgZ3JhcGhpcWw6IE1ldGVvci5pc0RldmVsb3BtZW50LFxuICAvLyBHcmFwaGlRTCBlbmRwb2ludFxuICBncmFwaGlxbFBhdGg6ICcvZ3JhcGhpcWwnLFxuICAvLyBHcmFwaGlRTCBvcHRpb25zIChkZWZhdWx0OiBsb2cgdGhlIGN1cnJlbnQgdXNlciBpbiB5b3VyIHJlcXVlc3QpXG4gIGdyYXBoaXFsT3B0aW9uczoge1xuICAgIHBhc3NIZWFkZXI6IFwiJ21ldGVvci1sb2dpbi10b2tlbic6IGxvY2FsU3RvcmFnZVsnTWV0ZW9yLmxvZ2luVG9rZW4nXVwiLFxuICB9LFxufTtcblxuLy8gZGVmYXVsdCBncmFwaHFsIG9wdGlvbnMgdG8gZW5oYW5jZSB0aGUgZ3JhcGhRTEV4cHJlc3Mgc2VydmVyXG5jb25zdCBkZWZhdWx0R3JhcGhRTE9wdGlvbnMgPSB7XG4gIC8vIGVuc3VyZSB0aGF0IGEgY29udGV4dCBvYmplY3QgaXMgZGVmaW5lZCBmb3IgdGhlIHJlc29sdmVyc1xuICBjb250ZXh0OiB7fSxcbiAgLy8gZXJyb3IgZm9ybWF0dGluZ1xuICBmb3JtYXRFcnJvcjogZSA9PiAoe1xuICAgIG1lc3NhZ2U6IGUubWVzc2FnZSxcbiAgICBsb2NhdGlvbnM6IGUubG9jYXRpb25zLFxuICAgIHBhdGg6IGUucGF0aCxcbiAgfSksXG4gIC8vIGFkZGl0aW9uYWwgZGVidWcgbG9nZ2luZyBpZiBleGVjdXRpb24gZXJyb3JzIG9jY3VyIGluIGRldiBtb2RlXG4gIGRlYnVnOiBNZXRlb3IuaXNEZXZlbG9wbWVudCxcbn07XG5cbmV4cG9ydCBjb25zdCBjcmVhdGVBcG9sbG9TZXJ2ZXIgPSAoY3VzdG9tT3B0aW9ucyA9IHt9LCBjdXN0b21Db25maWcgPSB7fSkgPT4ge1xuICAvLyBjcmVhdGUgYSBuZXcgc2VydmVyIGNvbmZpZyBvYmplY3QgYmFzZWQgb24gdGhlIGRlZmF1bHQgc2VydmVyIGNvbmZpZ1xuICAvLyBkZWZpbmVkIGFib3ZlIGFuZCB0aGUgY3VzdG9tIHNlcnZlciBjb25maWcgcGFzc2VkIHRvIHRoaXMgZnVuY3Rpb25cbiAgY29uc3QgY29uZmlnID0ge1xuICAgIC4uLmRlZmF1bHRTZXJ2ZXJDb25maWcsXG4gICAgLi4uY3VzdG9tQ29uZmlnLFxuICB9O1xuXG4gIGlmIChjdXN0b21Db25maWcuZ3JhcGhpcWxPcHRpb25zKSB7XG4gICAgY29uZmlnLmdyYXBoaXFsT3B0aW9ucyA9IHtcbiAgICAgIC4uLmRlZmF1bHRTZXJ2ZXJDb25maWcuZ3JhcGhpcWxPcHRpb25zLFxuICAgICAgLi4uY3VzdG9tQ29uZmlnLmdyYXBoaXFsT3B0aW9ucyxcbiAgICB9O1xuICB9XG5cbiAgLy8gdGhlIE1ldGVvciBHcmFwaFFMIHNlcnZlciBpcyBhbiBFeHByZXNzIHNlcnZlclxuICBjb25zdCBncmFwaFFMU2VydmVyID0gZXhwcmVzcygpO1xuXG4gIC8vIGVuaGFuY2UgdGhlIEdyYXBoUUwgc2VydmVyIHdpdGggcG9zc2libGUgZXhwcmVzcyBtaWRkbGV3YXJlc1xuICBjb25maWcuY29uZmlnU2VydmVyKGdyYXBoUUxTZXJ2ZXIpO1xuXG4gIC8vIEdyYXBoUUwgZW5kcG9pbnQsIGVuaGFuY2VkIHdpdGggSlNPTiBib2R5IHBhcnNlclxuICBncmFwaFFMU2VydmVyLnVzZShcbiAgICBjb25maWcucGF0aCxcbiAgICBib2R5UGFyc2VyLmpzb24oKSxcbiAgICBncmFwaHFsRXhwcmVzcyhhc3luYyByZXEgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gZ3JhcGhxbEV4cHJlc3MgY2FuIGFjY2VwdCBhIGZ1bmN0aW9uIHJldHVybmluZyB0aGUgb3B0aW9uIG9iamVjdFxuICAgICAgICBjb25zdCBjdXN0b21PcHRpb25zT2JqZWN0ID1cbiAgICAgICAgICB0eXBlb2YgY3VzdG9tT3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJyA/IGN1c3RvbU9wdGlvbnMocmVxKSA6IGN1c3RvbU9wdGlvbnM7XG5cbiAgICAgICAgLy8gY3JlYXRlIGEgbmV3IGFwb2xsbyBvcHRpb25zIG9iamVjdCBiYXNlZCBvbiB0aGUgZGVmYXVsdCBhcG9sbG8gb3B0aW9uc1xuICAgICAgICAvLyBkZWZpbmVkIGFib3ZlIGFuZCB0aGUgY3VzdG9tIGFwb2xsbyBvcHRpb25zIHBhc3NlZCB0byB0aGlzIGZ1bmN0aW9uXG4gICAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgICAgLi4uZGVmYXVsdEdyYXBoUUxPcHRpb25zLFxuICAgICAgICAgIC4uLmN1c3RvbU9wdGlvbnNPYmplY3QsXG4gICAgICAgIH07XG5cbiAgICAgICAgLy8gZ2V0IHRoZSBsb2dpbiB0b2tlbiBmcm9tIHRoZSBoZWFkZXJzIHJlcXVlc3QsIGdpdmVuIGJ5IHRoZSBNZXRlb3Inc1xuICAgICAgICAvLyBuZXR3b3JrIGludGVyZmFjZSBtaWRkbGV3YXJlIGlmIGVuYWJsZWRcbiAgICAgICAgY29uc3QgbG9naW5Ub2tlbiA9IHJlcS5oZWFkZXJzWydtZXRlb3ItbG9naW4tdG9rZW4nXTtcblxuICAgICAgICAvLyBnZXQgdGhlIGN1cnJlbnQgdXNlciAmIHRoZSB1c2VyIGlkIGZvciB0aGUgY29udGV4dFxuICAgICAgICBjb25zdCB1c2VyQ29udGV4dCA9IGF3YWl0IGdldFVzZXJGb3JDb250ZXh0KGxvZ2luVG9rZW4pO1xuXG4gICAgICAgIC8vIGNvbnRleHQgY2FuIGFjY2VwdCBhIGZ1bmN0aW9uIHJldHVybmluZyB0aGUgY29udGV4dCBvYmplY3RcbiAgICAgICAgY29uc3QgY29udGV4dCA9XG4gICAgICAgICAgdHlwZW9mIG9wdGlvbnMuY29udGV4dCA9PT0gJ2Z1bmN0aW9uJ1xuICAgICAgICAgICAgPyBhd2FpdCBvcHRpb25zLmNvbnRleHQodXNlckNvbnRleHQpXG4gICAgICAgICAgICA6IHsgLi4ub3B0aW9ucy5jb250ZXh0LCAuLi51c2VyQ29udGV4dCB9O1xuXG4gICAgICAgIC8vIHJldHVybiB0aGUgY29uZmlndXJlZCBvcHRpb25zIHRvIGJlIHVzZWQgYnkgdGhlIGdyYXBocWwgc2VydmVyXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gc29tZXRoaW5nIHdlbnQgYmFkIHdoZW4gY29uZmlndXJpbmcgdGhlIGdyYXBocWwgc2VydmVyLCB3ZSBkbyBub3RcbiAgICAgICAgLy8gc3dhbGxvdyB0aGUgZXJyb3IgYW5kIGRpc3BsYXkgaXQgaW4gdGhlIHNlcnZlci1zaWRlIGxvZ3NcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICAnW01ldGVvciBBcG9sbG8gSW50ZWdyYXRpb25dIFNvbWV0aGluZyBiYWQgaGFwcGVuZWQgd2hlbiBoYW5kbGluZyBhIHJlcXVlc3Qgb24gdGhlIEdyYXBoUUwgc2VydmVyLiBZb3VyIEdyYXBoUUwgc2VydmVyIGlzIG5vdCB3b3JraW5nIGFzIGV4cGVjdGVkOicsXG4gICAgICAgICAgZXJyb3JcbiAgICAgICAgKTtcblxuICAgICAgICAvLyByZXR1cm4gdGhlIGRlZmF1bHQgZ3JhcGhxbCBvcHRpb25zIGFueXdheVxuICAgICAgICByZXR1cm4gZGVmYXVsdEdyYXBoUUxPcHRpb25zO1xuICAgICAgfVxuICAgIH0pXG4gICk7XG5cbiAgLy8gU3RhcnQgR3JhcGhpUUwgaWYgZW5hYmxlZFxuICBpZiAoY29uZmlnLmdyYXBoaXFsKSB7XG4gICAgLy8gR3JhcGhpUUwgZW5kcG9pbnRcbiAgICBncmFwaFFMU2VydmVyLnVzZShcbiAgICAgIGNvbmZpZy5ncmFwaGlxbFBhdGgsXG4gICAgICBncmFwaGlxbEV4cHJlc3Moe1xuICAgICAgICAvLyBHcmFwaGlRTCBvcHRpb25zXG4gICAgICAgIC4uLmNvbmZpZy5ncmFwaGlxbE9wdGlvbnMsXG4gICAgICAgIC8vIGVuZHBvaW50IG9mIHRoZSBncmFwaHFsIHNlcnZlciB3aGVyZSB0byBzZW5kIHJlcXVlc3RzXG4gICAgICAgIGVuZHBvaW50VVJMOiBjb25maWcucGF0aCxcbiAgICAgIH0pXG4gICAgKTtcbiAgfVxuICAvLyB0aGlzIGJpbmRzIHRoZSBzcGVjaWZpZWQgcGF0aHMgdG8gdGhlIEV4cHJlc3Mgc2VydmVyIHJ1bm5pbmcgQXBvbGxvICsgR3JhcGhpUUxcbiAgV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoZ3JhcGhRTFNlcnZlcik7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0VXNlckZvckNvbnRleHQgPSBhc3luYyBsb2dpblRva2VuID0+IHtcbiAgLy8gdGhlcmUgaXMgYSBwb3NzaWJsZSBjdXJyZW50IHVzZXIgY29ubmVjdGVkIVxuICBpZiAobG9naW5Ub2tlbikge1xuICAgIC8vIHRocm93IGFuIGVycm9yIGlmIHRoZSB0b2tlbiBpcyBub3QgYSBzdHJpbmdcbiAgICBjaGVjayhsb2dpblRva2VuLCBTdHJpbmcpO1xuXG4gICAgLy8gdGhlIGhhc2hlZCB0b2tlbiBpcyB0aGUga2V5IHRvIGZpbmQgdGhlIHBvc3NpYmxlIGN1cnJlbnQgdXNlciBpbiB0aGUgZGJcbiAgICBjb25zdCBoYXNoZWRUb2tlbiA9IEFjY291bnRzLl9oYXNoTG9naW5Ub2tlbihsb2dpblRva2VuKTtcblxuICAgIC8vIGdldCB0aGUgcG9zc2libGUgY3VycmVudCB1c2VyIGZyb20gdGhlIGRhdGFiYXNlXG4gICAgLy8gbm90ZTogbm8gbmVlZCBvZiBhIGZpYmVyIGF3YXJlIGZpbmRPbmUgKyBhIGZpYmVyIGF3YXJlIGNhbGwgYnJlYWsgdGVzdHNcbiAgICAvLyBydW5uZWQgd2l0aCBwcmFjdGljYWxtZXRlb3I6bW9jaGEgaWYgZXNsaW50IGlzIGVuYWJsZWRcbiAgICBjb25zdCBjdXJyZW50VXNlciA9IGF3YWl0IE1ldGVvci51c2Vycy5yYXdDb2xsZWN0aW9uKCkuZmluZE9uZSh7XG4gICAgICAnc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zLmhhc2hlZFRva2VuJzogaGFzaGVkVG9rZW4sXG4gICAgfSk7XG5cbiAgICAvLyB0aGUgY3VycmVudCB1c2VyIGV4aXN0c1xuICAgIGlmIChjdXJyZW50VXNlcikge1xuICAgICAgLy8gZmluZCB0aGUgcmlnaHQgbG9naW4gdG9rZW4gY29ycmVzcG9uZGluZywgdGhlIGN1cnJlbnQgdXNlciBtYXkgaGF2ZVxuICAgICAgLy8gc2V2ZXJhbCBzZXNzaW9ucyBsb2dnZWQgb24gZGlmZmVyZW50IGJyb3dzZXJzIC8gY29tcHV0ZXJzXG4gICAgICBjb25zdCB0b2tlbkluZm9ybWF0aW9uID0gY3VycmVudFVzZXIuc2VydmljZXMucmVzdW1lLmxvZ2luVG9rZW5zLmZpbmQoXG4gICAgICAgIHRva2VuSW5mbyA9PiB0b2tlbkluZm8uaGFzaGVkVG9rZW4gPT09IGhhc2hlZFRva2VuXG4gICAgICApO1xuXG4gICAgICAvLyBnZXQgYW4gZXhwbG9pdGFibGUgdG9rZW4gZXhwaXJhdGlvbiBkYXRlXG4gICAgICBjb25zdCBleHBpcmVzQXQgPSBBY2NvdW50cy5fdG9rZW5FeHBpcmF0aW9uKHRva2VuSW5mb3JtYXRpb24ud2hlbik7XG5cbiAgICAgIC8vIHRydWUgaWYgdGhlIHRva2VuIGlzIGV4cGlyZWRcbiAgICAgIGNvbnN0IGlzRXhwaXJlZCA9IGV4cGlyZXNBdCA8IG5ldyBEYXRlKCk7XG5cbiAgICAgIC8vIGlmIHRoZSB0b2tlbiBpcyBzdGlsbCB2YWxpZCwgZ2l2ZSBhY2Nlc3MgdG8gdGhlIGN1cnJlbnQgdXNlclxuICAgICAgLy8gaW5mb3JtYXRpb24gaW4gdGhlIHJlc29sdmVycyBjb250ZXh0XG4gICAgICBpZiAoIWlzRXhwaXJlZCkge1xuICAgICAgICAvLyByZXR1cm4gYSBuZXcgY29udGV4dCBvYmplY3Qgd2l0aCB0aGUgY3VycmVudCB1c2VyICYgaGVyIGlkXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdXNlcjogY3VycmVudFVzZXIsXG4gICAgICAgICAgdXNlcklkOiBjdXJyZW50VXNlci5faWQsXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHt9O1xufTtcblxuLy8gdGFrZSB0aGUgZXhpc3RpbmcgY29udGV4dCBhbmQgcmV0dXJuIGEgbmV3IGV4dGVuZGVkIGNvbnRleHQgd2l0aCB0aGUgY3VycmVudFxuLy8gdXNlciBpZiByZWxldmFudCAoaS5lLiB2YWxpZCBsb2dpbiB0b2tlbilcbmV4cG9ydCBjb25zdCBhZGRDdXJyZW50VXNlclRvQ29udGV4dCA9IGFzeW5jIChjb250ZXh0LCBsb2dpblRva2VuKSA9PiB7XG4gIGNvbnN0IHVzZXJDb250ZXh0ID0gYXdhaXQgZ2V0VXNlckZvckNvbnRleHQobG9naW5Ub2tlbik7XG4gIHJldHVybiB7XG4gICAgLi4uY29udGV4dCxcbiAgICAuLi51c2VyQ29udGV4dCxcbiAgfTtcbn07XG4iXX0=
