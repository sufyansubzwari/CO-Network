(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var STRIPEMETEOR;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mrgalaxy_stripe/stripe_server.js                         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
this.StripeAPI = Npm.require('stripe');
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("mrgalaxy:stripe", {
  STRIPEMETEOR: STRIPEMETEOR
});

})();
