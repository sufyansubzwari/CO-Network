function(t,a,i){i.watch(t("./password-auth-views"),{default(t){a.PasswordAuthViews=t}},0),i.watch(t("./fb-auth-btn"),{default(t){a.FBAuthBtn=t}},1),i.watch(t("./resend-verification-link"),{default(t){a.ResendVerificationLink=t}},2),i.watch(t("./logout-btn"),{default(t){a.LogoutBtn=t}},3)}

