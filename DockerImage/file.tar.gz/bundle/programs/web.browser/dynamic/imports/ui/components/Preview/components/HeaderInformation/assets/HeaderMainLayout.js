function(o,t,e){const a=e;let c,n,r;a.watch(o("react"),{default(o){c=o}},0),a.watch(o("styled-components"),{default(o){n=o}},1),a.watch(o("btech-layout"),{Layout(o){r=o}},2);const l=n(r).withConfig({displayName:"HeaderMainLayout",componentId:"sc-5hybea-0"})(["border-bottom:",";background-color:",";"],o=>"1px solid "+o.theme.color.grey,o=>o.theme.color.innerBackground);a.exportDefault(l)}

