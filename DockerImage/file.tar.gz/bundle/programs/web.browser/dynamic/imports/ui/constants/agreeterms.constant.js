function(e,t,n){n.export({AgreePayments:()=>o});const o={licenseTerms:{link:"https://www.innovation-labs.co/co-network-%CE%B1/policies-privacy-and-etiquette",color:"blue",target:"_blank"},userTerms:{link:"https://www.innovation-labs.co/co-network-%CE%B1/policies-privacy-and-etiquette",color:"blue",target:"_blank"}}}

