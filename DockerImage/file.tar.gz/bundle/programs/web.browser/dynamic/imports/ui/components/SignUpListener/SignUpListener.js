function(t,e,s){const o=s;let r,n,i;o.watch(t("react"),{default(t){r=t},Component(t){n=t}},0),o.watch(t("react-router-dom"),{withRouter(t){i=t}},1);class p extends n{componentWillReceiveProps(t){!t.curUser||this.props.isSignUp||/sign-up/.test(this.props.location.pathname)||this.props.history.push("/sign-up")}render(){return!1}}o.exportDefault(i(p))}

