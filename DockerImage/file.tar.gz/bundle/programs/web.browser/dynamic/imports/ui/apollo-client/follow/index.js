function(t,i,n){n.watch(t("./mutations.graphql"),{default(t){i.FollowAction=t}},0)}

