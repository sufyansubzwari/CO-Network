function(e,t,o){o.watch(e("./queries.graphql"),{GetJobs(e){t.GetJobs=e},JobCounts(e){t.JobCounts=e},GetMyJobs(e){t.GetMyJobs=e},GetJob(e){t.GetJob=e}},0),o.watch(e("./mutations.graphql"),{CreateJob(e){t.CreateJob=e},DeleteJob(e){t.DeleteJob=e},UpdateJobsImage(e){t.UpdateJobsImage=e}},1)}

