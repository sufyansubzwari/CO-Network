function(e,t,i){i.watch(e("./queries.graphql"),{default(e){t.GetStripeCustomers=e}},0)}

