function(t,e,S){let d,i,p;S.export({FirstStep:()=>d,SecondStep:()=>i,ThirdStep:()=>p}),S.watch(t("./FirstStep"),{default(t){d=t}},0),S.watch(t("./SecondStep"),{default(t){i=t}},1),S.watch(t("./ThirdStep"),{default(t){p=t}},2)}

