function(e,t,n){const a=n;let o,c;a.watch(e("react"),{default(e){o=e}},0),a.watch(e("styled-components"),{default(e){c=e}},1);const f=c.div.withConfig({displayName:"SType",componentId:"sc-1njnzwf-0"})(["font-family:Helvetica Neue Light;font-size:12px;text-transform:",";"],e=>e.uppercase?"uppercase":"none");a.exportDefault(f)}

