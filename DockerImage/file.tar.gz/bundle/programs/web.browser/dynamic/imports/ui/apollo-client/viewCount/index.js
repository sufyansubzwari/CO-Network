function(t,a,i){i.watch(t("./mutations.graphql"),{default(t){a.ViewsCountUpdate=t}},0)}

