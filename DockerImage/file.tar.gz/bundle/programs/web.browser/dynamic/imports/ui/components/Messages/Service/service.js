function(e,s,t){let c;t.export({insertMessage:()=>a,updateMessage:()=>n}),t.watch(e("meteor/meteor"),{Meteor(e){c=e}},0);const a=(e,s)=>{c.call("messages.insert",e,e=>s(e||"success"))},n=(e,s)=>{c.call("messages.update",e,e=>s(e||"success"))};function r(){return!0}}

