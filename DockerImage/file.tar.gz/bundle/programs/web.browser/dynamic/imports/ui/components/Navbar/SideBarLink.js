function(o,t,e){const n=e;let i;n.watch(o("styled-components"),{default(o){i=o}},0);const s=i.a.withConfig({displayName:"SideBarLink",componentId:"sc-74za4v-0"})(["font-size:",";text-decoration:none;color:",";",";"],o=>o.fontSize||o.theme.sidebar.bottomLinks.fontSize,o=>o.color||o.theme.sidebar.bottomLinks.color,o=>o.pointer&&"cursor:pointer;");n.exportDefault(s)}

