function(e,a,l){l.export({SPEAKERS_SPONSORS:()=>t,EXPERIENCE_LEVEL:()=>n,DEGREE_LEVEL:()=>p});const t=[{label:"Speakers",type:"Speakers"},{label:"Sponsors",type:"Sponsors"}],n=[{label:"Advanced",type:"Advanced"},{label:"Intermediate",type:"Intermediate"},{label:"Beginner",type:"Beginner"}],p=[{label:"Bachelor",type:"Bachelor"},{label:"Master",type:"Master"},{label:"P.h.D",type:"P.h.D"}]}

