function(e,s,r){r.watch(e("./queries.graphql"),{GetSponsors(e){s.GetSponsors=e},GetSpeakers(e){s.GetSpeakers=e}},0)}

