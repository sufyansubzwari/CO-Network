function(e,t,n){let i;n.watch(e("styled-components"),{default(e){i=e}},0);const o=i.fieldset.withConfig({displayName:"fieldset__Fieldset",componentId:"ql5yot-0"})(["border:none;padding:0;margin-left:0;margin-right:0;"]);n.exportDefault(o)}

