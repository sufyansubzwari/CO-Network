function(t,e,a){let o,c,l,n;a.watch(t("react"),{default(t){o=t}},0),a.watch(t("react-router-dom"),{Link(t){c=t}},1),a.watch(t("../components/smart/seo"),{default(t){l=t}},2),a.watch(t("../layouts/auth-page"),{default(t){n=t}},3);const u=()=>[o.createElement(n,{key:"view",title:"404 - Page Not Found",subtitle:"Back to",link:o.createElement(c,{to:"/"},"Home")})];a.exportDefault(u)}

