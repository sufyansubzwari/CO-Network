function(t,n,e){let a;function c(t){return{type:a.ON_SEARCH,tag:t}}function r(){return{type:a.CLEAN_SEARCH,tag:null}}e.export({onSearchTags:()=>c,cleanSearch:()=>r}),e.watch(t("./types"),{"*"(t){a=t}},0)}

