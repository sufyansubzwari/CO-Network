function(t,o,n){let u,a,e;n.export({LoginButtons:()=>u,ZoomButtons:()=>a,Signature:()=>e}),n.watch(t("./LoginButtons"),{default(t){u=t}},0),n.watch(t("./ZoomButtons"),{default(t){a=t}},1),n.watch(t("./Signature"),{default(t){e=t}},2)}

