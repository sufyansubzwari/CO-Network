function(e,t,l){l.export({PRODUCTS_TYPES:()=>a,EXPERIENCE_LEVEL:()=>r,DEGREE_LEVEL:()=>n});const a=[{label:"Product",type:"Product"},{label:"Service",type:"Service"}],r=[{label:"Advanced",type:"Advanced"},{label:"Intermediate",type:"Intermediate"},{label:"Beginner",type:"Beginner"}],n=[{label:"Bachelor",type:"Bachelor"},{label:"Master",type:"Master"},{label:"P.h.D",type:"P.h.D"}]}

