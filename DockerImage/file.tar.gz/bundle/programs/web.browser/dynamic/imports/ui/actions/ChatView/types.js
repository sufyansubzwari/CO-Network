function(_,E,C){C.export({OPEN_CHAT_VIEW:()=>n,CLOSE_CHAT_VIEW:()=>A});const n="OPEN_CHAT_VIEW",A="CLOSE_CHAT_VIEW"}

