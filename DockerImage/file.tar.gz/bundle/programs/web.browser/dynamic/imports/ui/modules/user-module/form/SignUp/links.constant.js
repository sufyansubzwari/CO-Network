function(o,l,t){t.exportDefault({termsConditions:{link:"http://www.google.com",color:"blue",target:"_blank"},privacyPolicy:{link:"http://www.google.com",color:"blue",target:"_blank"},spamPolicy:{link:"http://www.google.com",color:"blue",target:"_blank"}})}

