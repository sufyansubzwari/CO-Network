function(o,t,n){const e=n;let f,a;e.watch(o("react"),{default(o){f=o}},0),e.watch(o("styled-components"),{default(o){a=o}},1);const c=a.div.withConfig({displayName:"SContent",componentId:"pxbppy-0"})(["background-color:#202225;color:#fff;font-family:Roboto Mono;padding:5px;font-size:11px;"]);e.exportDefault(c)}

