function(n,i,o){o.export({LOADINGDATA:()=>t});const t=[1,2,3,4,5]}

