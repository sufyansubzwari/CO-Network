function(e,t,i){i.export({ticketsTypes:()=>c});const c=[{label:"Free Ticket",type:"free"},{label:"Paid Ticket",type:"paid"}]}

