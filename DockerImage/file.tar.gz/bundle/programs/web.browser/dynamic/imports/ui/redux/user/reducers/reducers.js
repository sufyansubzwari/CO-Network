function(t,e,n){let l;n.export({userState:()=>u}),n.watch(t("../types"),{EVENT_UPDATE_USER(t){l=t}},0);const u=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:null,e=arguments.length>1?arguments[1]:void 0;switch(e.type){case l:return e.status||null;default:return t}}}

