function(i,e,t){t.exportDefault([{label:"google",service:"google-oauth2",link:"https://plus.google.com",visible:!0},{service:"facebook",link:"https://www.facebook.com",visible:!0},{service:"google+",link:"",visible:!1},{service:"twitter",link:"https://twitter.com",visible:!0},{service:"github",link:"https://github.com",visible:!0}])}

