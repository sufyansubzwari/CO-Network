function(t,e,i){let n;function y(t,e,i){return{showPreview:!!t,entity:t,entityType:i,type:t?n.SHOW_PREVIEW:n.HIDE_PREVIEW}}i.export({PreviewData:()=>y}),i.watch(t("./types"),{"*"(t){n=t}},0)}

