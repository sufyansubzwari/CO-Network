function(e,i,t){t.watch(e("./queries.graphql"),{default(e){i.GetTickets=e}},0)}

