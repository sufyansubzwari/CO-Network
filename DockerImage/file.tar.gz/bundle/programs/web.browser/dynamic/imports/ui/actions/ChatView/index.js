function(t,e,n){let o;function i(){return{type:o.CLOSE_CHAT_VIEW,show:!1}}function _(){return{type:o.OPEN_CHAT_VIEW,show:!0}}n.export({closeChatView:()=>i,openChatView:()=>_}),n.watch(t("./types"),{"*"(t){o=t}},0)}

