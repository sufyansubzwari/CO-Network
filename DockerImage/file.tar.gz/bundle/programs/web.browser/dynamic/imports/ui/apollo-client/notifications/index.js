function(t,i,a){a.watch(t("./queries.graphql"),{default(t){i.GetNotifications=t}},0),a.watch(t("./mutations.graphql"),{DeleteNotification(t){i.DeleteNotification=t},UpdateNotification(t){i.UpdateNotification=t}},1)}

