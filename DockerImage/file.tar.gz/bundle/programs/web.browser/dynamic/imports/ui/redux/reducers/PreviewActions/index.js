function(t,e,n){let i;n.watch(t("../../../actions/PreviewActions/types"),{"*"(t){i=t}},0);const s={showPreview:!1,entity:null,entityType:""},c=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,e=arguments.length>1?arguments[1]:void 0;switch(e.type){case i.SHOW_PREVIEW:case i.HIDE_PREVIEW:return Object.assign({},t,e);default:return t}};n.exportDefault(c)}

