function(t,i,n){let e;n.export({List:()=>e}),n.watch(t("./list-component/List"),{default(t){e=t}},0)}

