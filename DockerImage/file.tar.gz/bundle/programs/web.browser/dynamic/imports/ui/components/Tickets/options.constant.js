function(e,t,i){i.export({ticketsTypes:()=>c,ticketCharge:()=>a});const c=[{label:"Free Ticket",type:"free"},{label:"Paid Ticket",type:"paid"}],a=6}

