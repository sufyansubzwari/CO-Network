function(t,n,i){let e;i.watch(t("styled-components"),{default(t){e=t}},0);const d=e.input.withConfig({displayName:"input__Input",componentId:"j5wfw2-0"})(["width:100%;height:34px;border:solid 1px black;padding-left:14px;padding-right:14px;outline:none;border-radius:0;"]);i.exportDefault(d)}

