function(t,o,e){e.watch(t("./scroll-to-top"),{default(t){o.ScrollToTop=t}},0),e.watch(t("./logged-in-route"),{default(t){o.LoggedInRoute=t}},1),e.watch(t("./logged-out-route"),{default(t){o.LoggedOutRoute=t}},2),e.watch(t("./route-with-props"),{default(t){o.RouteWithProps=t}},3),e.watch(t("./admin-route"),{default(t){o.AdminRoute=t}},4)}

