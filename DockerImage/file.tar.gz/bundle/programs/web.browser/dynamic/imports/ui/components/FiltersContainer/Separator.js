function(t,e,o){const a=o;let i,n;a.watch(t("react"),{default(t){i=t}},0),a.watch(t("styled-components"),{default(t){n=t}},1);const c=n.div.withConfig({displayName:"Separator",componentId:"xh4ii4-0"})(["height:1px;width:100%;opacity:0.5;background-color:",";"],t=>t.invert?"#FFFFFF":t.theme.filter.separatorColor);a.exportDefault(c)}

