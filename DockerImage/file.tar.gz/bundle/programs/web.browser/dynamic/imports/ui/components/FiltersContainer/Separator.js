function(t,e,o){const a=o;let i,c;a.watch(t("react"),{default(t){i=t}},0),a.watch(t("styled-components"),{default(t){c=t}},1);const n=c.div.withConfig({displayName:"Separator",componentId:"xh4ii4-0"})(["height:1px;width:100%;opacity:0.5;background-color:",";"],t=>t.theme?t.theme.filter.separatorColor:"black");a.exportDefault(n)}

