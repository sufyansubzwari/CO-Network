function(n,o,i){i.export({CREATE_LINKS:()=>t});const t=[{name:"Event",link:"/post-event"},{name:"Job",link:"/post-job"},{name:"Organization",link:"/post-organization"},{name:"Colloquium",link:"/post-colloquium"}]}

