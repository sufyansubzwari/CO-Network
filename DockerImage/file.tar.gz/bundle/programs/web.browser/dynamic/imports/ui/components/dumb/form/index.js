function(t,o,e){let n;e.watch(t("styled-components"),{default(t){n=t}},0);const f=n.form.withConfig({displayName:"form__Form",componentId:"sc-1ury0ee-0"})(["width:100%;"]);e.exportDefault(f)}

