function(e,t,n){n.watch(e("./queries.graphql"),{GetEvents(e){t.GetEvents=e},GetMyEvents(e){t.GetMyEvents=e},GetEvent(e){t.GetEvent=e}},0),n.watch(e("./mutations.graphql"),{CreateEvent(e){t.CreateEvent=e},DeleteEvent(e){t.DeleteEvent=e},UpdateImageEvent(e){t.UpdateImageEvent=e}},1)}

