function(t,n,e){const o=e;let a,i,c;o.watch(t("react"),{default(t){a=t}},0),o.watch(t("styled-components"),{default(t){i=t}},1),o.watch(t("btech-layout"),{Container(t){c=t}},2);const p=i(c).withConfig({displayName:"MenuOption",componentId:"sc-10kkxpl-0"})(["font-size:14px;i{padding-right:5px;}"]);o.exportDefault(p)}

