function(t,e,n){let i;n.watch(t("../../../actions/ChatView/types"),{"*"(t){i=t}},0);const s={show:!1,type:i.CLOSE_CHAT_VIEW},c=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,e=arguments.length>1?arguments[1]:void 0;switch(e.type){case i.OPEN_CHAT_VIEW:case i.CLOSE_CHAT_VIEW:return Object.assign({},t,e);default:return t}};n.exportDefault(c)}

