function(E,_,n){n.export({CHANGE_MOBILE_VIEW:()=>I});const I="CHANGE_MOBILE_VIEW"}

