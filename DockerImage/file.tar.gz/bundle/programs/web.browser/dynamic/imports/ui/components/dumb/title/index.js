function(e,t,r){let c,n;r.watch(e("react"),{default(e){c=e}},0),r.watch(e("prop-types"),{default(e){n=e}},1);const a=e=>{let{children:t}=e;return c.createElement("h1",{className:"center"},t)};a.propTypes={children:n.string.isRequired},r.exportDefault(a)}

