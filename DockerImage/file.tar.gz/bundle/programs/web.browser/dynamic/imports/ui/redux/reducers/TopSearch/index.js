function(t,e,n){let c;n.export({topSearch:()=>o}),n.watch(t("../../../actions/TopSearchActions/types"),{"*"(t){c=t}},0);const i={type:null,tag:null},o=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:i,e=arguments.length>1?arguments[1]:void 0;switch(e.type){case c.ON_SEARCH:case c.CLEAN_SEARCH:return Object.assign({},t,e);default:return t}}}

