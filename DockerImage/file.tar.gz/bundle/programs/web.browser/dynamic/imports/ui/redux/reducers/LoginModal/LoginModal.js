function(t,e,n){let i;n.watch(t("../../../actions/LoginModalActions/types"),{"*"(t){i=t}},0);const o={show:!1},s=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:o,e=arguments.length>1?arguments[1]:void 0;switch(e.type){case i.LOGIN_MODAL_SHOW:case i.LOGIN_MODAL_HIDEN:return Object.assign({},t,e);default:return t}};n.exportDefault(s)}

