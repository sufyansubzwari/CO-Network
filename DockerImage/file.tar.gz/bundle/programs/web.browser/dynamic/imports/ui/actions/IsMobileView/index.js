function(t,e,i){let n;function s(t){return{type:n.CHANGE_MOBILE_VIEW,status:t}}i.export({isMobileView:()=>s}),i.watch(t("./types"),{"*"(t){n=t}},0)}

