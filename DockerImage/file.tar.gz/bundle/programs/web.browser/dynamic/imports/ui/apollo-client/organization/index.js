function(e,t,r){r.watch(e("./queries.graphql"),{GetOrgs(e){t.GetOrgs=e},GetOrgFilters(e){t.GetOrgFilters=e},GetOrg(e){t.GetOrg=e}},0),r.watch(e("./mutations.graphql"),{CreateOrg(e){t.CreateOrg=e},DeleteOrg(e){t.DeleteOrg=e},UpdateOrgImages(e){t.UpdateOrgImages=e},UpdateIdentitiesOrg(e){t.UpdateIdentitiesOrg=e}},1)}

