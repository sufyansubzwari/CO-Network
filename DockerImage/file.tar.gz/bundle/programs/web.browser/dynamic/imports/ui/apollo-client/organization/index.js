function(e,t,r){r.watch(e("./queries.graphql"),{GetOrg(e){t.GetOrg=e},GetOrgFilters(e){t.GetOrgFilters=e}},0),r.watch(e("./mutations.graphql"),{CreateOrg(e){t.CreateOrg=e},DeleteOrg(e){t.DeleteOrg=e},UpdateOrgImages(e){t.UpdateOrgImages=e},UpdateIdentitiesOrg(e){t.UpdateIdentitiesOrg=e}},1)}

