function(a,e,i){i.watch(a("./queries.graphql"),{default(a){e.GetTags=a}},0)}

