function(s,a,e){e.watch(s("./queries.graphql"),{GetTags(s){a.GetTags=s},TagsFilters(s){a.TagsFilters=s}},0)}

