function(e,t,o){let c,r,a;o.watch(e("redux"),{createStore(e){c=e},compose(e){r=e}},0),o.watch(e("./root-reducer.js"),{default(e){a=e}},1);const u=[];o.exportDefault(c(a,{},r(...u)))}

