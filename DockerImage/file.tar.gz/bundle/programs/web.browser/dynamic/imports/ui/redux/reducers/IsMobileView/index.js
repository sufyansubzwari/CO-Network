function(t,e,i){let n;i.export({isMobile:()=>o}),i.watch(t("../../../actions/IsMobileView/types"),{CHANGE_MOBILE_VIEW(t){n=t}},0);const o=function(){let t=arguments.length>0&&void 0!==arguments[0]&&arguments[0],e=arguments.length>1?arguments[1]:void 0;switch(e.type){case n:return e.status||!1;default:return t}};i.exportDefault(o)}

