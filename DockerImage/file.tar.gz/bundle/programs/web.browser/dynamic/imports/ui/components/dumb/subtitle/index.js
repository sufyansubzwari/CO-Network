function(e,t,l){let n,r;l.watch(e("react"),{default(e){n=e}},0),l.watch(e("prop-types"),{default(e){r=e}},1);const a=e=>{let{text:t,link:l}=e;return n.createElement("p",{className:"center"},n.createElement("span",{dangerouslySetInnerHTML:{__html:t}})," ",l||null)};a.propTypes={text:r.string.isRequired,link:r.object},a.defaultProps={link:null},l.exportDefault(a)}

