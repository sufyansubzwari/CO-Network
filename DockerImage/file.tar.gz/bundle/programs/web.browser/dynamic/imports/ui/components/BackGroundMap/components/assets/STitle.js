function(t,e,i){const n=i;let a,o;n.watch(t("react"),{default(t){a=t}},0),n.watch(t("styled-components"),{default(t){o=t}},1);const c=o.div.withConfig({displayName:"STitle",componentId:"auimmc-0"})(["font-family:Helvetica Neue LT Std;font-size:12px;"]);n.exportDefault(c)}

