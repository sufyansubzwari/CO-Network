function(l,u,o){o.watch(l("./queries.graphql"),{GetColloquiums(l){u.GetColloquiums=l},GetColloquium(l){u.GetColloquium=l}},0),o.watch(l("./mutations.graphql"),{CreateColloquium(l){u.CreateColloquium=l},DeleteColloquium(l){u.DeleteColloquium=l},UpdateColloquiumImage(l){u.UpdateColloquiumImage=l}},1)}

