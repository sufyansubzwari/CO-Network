function(l,e,u){u.watch(l("./queries.graphql"),{default(l){e.GetColloquiums=l}},0),u.watch(l("./mutations.graphql"),{CreateColloquium(l){e.CreateColloquium=l},DeleteColloquium(l){e.DeleteColloquium=l},UpdateColloquiumImage(l){e.UpdateColloquiumImage=l}},1)}

