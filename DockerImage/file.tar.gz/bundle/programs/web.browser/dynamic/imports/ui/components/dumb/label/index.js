function(e,n,l){let o;l.watch(e("styled-components"),{default(e){o=e}},0);const t=o.label.withConfig({displayName:"label__Label",componentId:"m0p6wa-0"})(["border:none;cursor:pointer;display:block;line-height:2;padding:0;"]);l.exportDefault(t)}

