function(t,e,o){let r,n,c;o.watch(t("react"),{default(t){r=t}},0),o.watch(t("prop-types"),{default(t){n=t}},1),o.watch(t("react-router-dom"),{withRouter(t){c=t}},2);class i extends r.Component{componentDidUpdate(t){this.props.location!==t.location&&window.scrollTo(0,0)}render(){return this.props.children}}i.propTypes={location:n.object.isRequired},o.exportDefault(c(i))}

