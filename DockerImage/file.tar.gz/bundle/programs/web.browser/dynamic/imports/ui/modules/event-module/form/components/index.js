function(t,e,n){let p,a,v,E,S;n.export({EventStep0:()=>p,EventStep1:()=>a,EventStep2:()=>v,EventStep3:()=>E,EventStep4:()=>S}),n.watch(t("./EventStep0"),{default(t){p=t}},0),n.watch(t("./EventStep1"),{default(t){a=t}},1),n.watch(t("./EventStep2"),{default(t){v=t}},2),n.watch(t("./EventStep3"),{default(t){E=t}},3),n.watch(t("./EventStep4"),{default(t){S=t}},4)}

