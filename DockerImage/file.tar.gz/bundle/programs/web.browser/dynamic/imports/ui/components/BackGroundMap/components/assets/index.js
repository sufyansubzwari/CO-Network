function(t,e,n){let a,l,S;n.export({STitle:()=>a,SType:()=>l,SContent:()=>S}),n.watch(t("./STitle"),{default(t){a=t}},0),n.watch(t("./SType"),{default(t){l=t}},1),n.watch(t("./SContent"),{default(t){S=t}},2)}

