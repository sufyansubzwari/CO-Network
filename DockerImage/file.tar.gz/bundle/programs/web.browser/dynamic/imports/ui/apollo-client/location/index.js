function(t,e,o){o.watch(t("./queries.graphql"),{default(t){e.GetLocations=t}},0),o.watch(t("./mutations.graphql"),{InsertLocation(t){e.InsertLocation=t},DeleteLocation(t){e.DeleteLocation=t}},1)}

