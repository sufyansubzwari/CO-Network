function(p,e,o){o.watch(p("./queries.graphql"),{GetJobApply(p){e.GetJobApply=p},JobApplyCounts(p){e.JobApplyCounts=p},GetSponsors(p){e.GetSponsors=p}},0),o.watch(p("./mutations.graphql"),{CreateJobApply(p){e.CreateJobApply=p},DeleteJobApply(p){e.DeleteJobApply=p},UpdateJobApplyImage(p){e.UpdateJobApplyImage=p}},1)}

