function(e,t,r){var a,i=e("@babel/runtime/helpers/builtin/interopRequireDefault")(e("@babel/runtime/helpers/builtin/objectSpread"));let u,c,l;r.watch(e("./reducers/reducers"),{"*"(e){u=e}},0),r.watch(e("./actions/actions"),{default(e){c=e}},1),r.watch(e("./types"),{"*"(e){l=e}},2);const n={reducers:(0,i.default)({},u),Actions:c,types:(0,i.default)({},l)};r.exportDefault(n)}

