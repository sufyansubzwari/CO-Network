function(t,o,a){let i,u,f,l,n;a.export({Authorization:()=>i,UploadToS3:()=>u,Utils:()=>f,ConfirmPopup:()=>l,NotificationToast:()=>n}),a.watch(t("./authorization"),{default(t){i=t}},0),a.watch(t("./uploadToS3"),{default(t){u=t}},1),a.watch(t("./util/utils"),{default(t){f=t}},2),a.watch(t("./ConfirmPopup"),{default(t){l=t}},3),a.watch(t("./NotificationToast"),{default(t){n=t}},4)}

