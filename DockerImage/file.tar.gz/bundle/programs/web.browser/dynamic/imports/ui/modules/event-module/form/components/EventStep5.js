function(t,e,n){const r=n;let s,c;r.watch(t("react"),{default(t){s=t},Component(t){c=t}},0);class l extends c{constructor(t){super(t)}render(){return s.createElement("div",null,this.props.title)}}r.exportDefault(l)}

