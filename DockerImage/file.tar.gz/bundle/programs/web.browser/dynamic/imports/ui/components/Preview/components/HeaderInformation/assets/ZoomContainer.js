function(t,o,e){const n=e;let a,i,m;n.watch(t("react"),{default(t){a=t}},0),n.watch(t("styled-components"),{default(t){i=t}},1),n.watch(t("btech-layout"),{Container(t){m=t}},2);const c=i(m).withConfig({displayName:"ZoomContainer",componentId:"sc-1beke82-0"})(["zoom:100%;@media (min-width:62em){zoom:80%;}@media (min-width:86em){zoom:100%;}"]);n.exportDefault(c)}

