function(n,o,t){let e;function i(){return{type:e.LOGIN_MODAL_SHOW,show:!0}}function _(){return{type:e.LOGIN_MODAL_HIDEN,show:!1}}t.export({loginModalShow:()=>i,loginModalHide:()=>_}),t.watch(n("./types"),{"*"(n){e=n}},0)}

