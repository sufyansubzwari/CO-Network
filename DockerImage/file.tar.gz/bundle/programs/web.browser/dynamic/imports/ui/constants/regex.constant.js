function(E,A,_){_.export({EMAIL_REGEX:()=>z,PHONE_REGEX:()=>a,NAME_REGEX:()=>n});const z=/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/,a=/^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/,n=/^[a-zA-ZA-zÀ-ú0-9'. ]{1,40}$/}

