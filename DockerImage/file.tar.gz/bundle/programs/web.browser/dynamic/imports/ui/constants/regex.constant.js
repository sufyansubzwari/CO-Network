function(E,_,z){z.export({EMAIL_REGEX:()=>a,PHONE_REGEX:()=>n,NAME_REGEX:()=>A});const a=/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/,n=/^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/,A=/^[a-zA-ZA-zÀ-ú0-9'. ]{1,40}$/}

