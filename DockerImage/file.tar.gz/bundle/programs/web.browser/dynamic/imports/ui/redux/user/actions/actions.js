function(t,e,s){let n;s.watch(t("../types"),{EVENT_UPDATE_USER(t){n=t}},0);const E={setUser:t=>({type:n,status:t})};s.exportDefault(E)}

